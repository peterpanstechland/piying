"""
Helper functions and utilities
"""
